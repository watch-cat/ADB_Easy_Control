# ADB Easy Control

A python package that makes it easier to control your android devices with ADB.  

With ADB Easy Control, you can integrate ADB instructions into Python programs in a more intuitive way, and ADB based scripts are easier to write. </br>
At the same time, ADB Easy Control is much lighter and portable than traditional Android device control software.